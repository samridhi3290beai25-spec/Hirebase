const captchaCodeEl = document.getElementById("captcha-code");
let currentCaptcha = "";

function generateCaptcha() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  currentCaptcha = code;
  if (captchaCodeEl) captchaCodeEl.textContent = code;
}

if (captchaCodeEl) {
  generateCaptcha();
  const refreshBtn = document.getElementById("captcha-refresh");
  if (refreshBtn) refreshBtn.addEventListener("click", generateCaptcha);
}

// Helper: Show field inline error
function setFieldError(fieldId, errorText) {
  const input = document.getElementById(fieldId);
  if (!input) return;
  input.classList.add("invalid");
  let errEl = input.parentNode.querySelector(".field-error-msg");
  if (!errEl) {
    errEl = document.createElement("div");
    errEl.className = "field-error-msg";
    input.parentNode.appendChild(errEl);
  }
  errEl.textContent = "⚠️ " + errorText;
}

// Helper: Clear field error
function clearFieldError(fieldId) {
  const input = document.getElementById(fieldId);
  if (!input) return;
  input.classList.remove("invalid");
  const errEl = input.parentNode.querySelector(".field-error-msg");
  if (errEl) errEl.remove();
}

// Real-time input cleaning
["email", "password", "captcha-input"].forEach(id => {
  const el = document.getElementById(id);
  if (el) {
    el.addEventListener("input", () => clearFieldError(id));
  }
});

document.getElementById("signin-form").addEventListener("submit", function (e) {
  e.preventDefault();

  let isValid = true;
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");
  const captchaInput = document.getElementById("captcha-input");
  const message = document.getElementById("signin-message");

  // Validate Email
  const emailVal = emailInput ? emailInput.value.trim() : "";
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailVal) {
    setFieldError("email", "Email address is required.");
    isValid = false;
  } else if (!emailRegex.test(emailVal)) {
    setFieldError("email", "Please enter a valid email address (e.g. name@domain.com).");
    isValid = false;
  } else {
    clearFieldError("email");
  }

  // Validate Password
  const passVal = passwordInput ? passwordInput.value : "";
  if (!passVal) {
    setFieldError("password", "Password is required.");
    isValid = false;
  } else if (passVal.length < 6) {
    setFieldError("password", "Password must be at least 6 characters.");
    isValid = false;
  } else {
    clearFieldError("password");
  }

  // Validate Captcha
  const capVal = captchaInput ? captchaInput.value.trim().toUpperCase() : "";
  if (!capVal) {
    setFieldError("captcha-input", "Security code is required.");
    isValid = false;
  } else if (capVal !== currentCaptcha) {
    setFieldError("captcha-input", "Security code did not match.");
    generateCaptcha();
    if (captchaInput) captchaInput.value = "";
    isValid = false;
  } else {
    clearFieldError("captcha-input");
  }

  if (!isValid) {
    if (message) {
      message.textContent = "Please correct the required fields highlighted above.";
      message.className = "form-message error";
    }
    return;
  }

  if (message) {
    message.textContent = "✓ Credentials verified. Launching portal...";
    message.className = "form-message success";
  }

  try {
    localStorage.setItem("hb_logged_in", "true");
  } catch (err) {}

  setTimeout(function () {
    window.location.href = "loading.html?type=signin";
  }, 600);
});

// ---------- Forgot password toggle & validation ----------
const forgotToggle = document.getElementById("forgot-toggle");
const forgotForm = document.getElementById("forgot-form");

if (forgotToggle && forgotForm) {
  forgotToggle.addEventListener("click", function () {
    const isHidden = forgotForm.hidden;
    forgotForm.hidden = !isHidden;
    forgotToggle.textContent = isHidden ? "Back to sign in" : "Forgot password?";
  });

  const forgotEmail = document.getElementById("forgot-email");
  if (forgotEmail) {
    forgotEmail.addEventListener("input", () => clearFieldError("forgot-email"));
  }

  forgotForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const forgotVal = forgotEmail ? forgotEmail.value.trim() : "";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const forgotMessage = document.getElementById("forgot-message");

    if (!forgotVal) {
      setFieldError("forgot-email", "Email is required to reset password.");
      return;
    } else if (!emailRegex.test(forgotVal)) {
      setFieldError("forgot-email", "Please enter a valid email address.");
      return;
    }

    clearFieldError("forgot-email");
    if (forgotMessage) {
      forgotMessage.textContent = "✓ If that email exists, a password reset link has been sent.";
      forgotMessage.className = "form-message success";
    }
  });
}
