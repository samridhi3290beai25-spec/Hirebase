// Helper: Show field inline error
function setFieldError(fieldId, errorText) {
  const input = document.getElementById(fieldId);
  if (!input) return;
  input.classList.add("invalid");
  let errEl = input.parentNode.querySelector(".field-error-msg");
  if (!errEl) {
    errEl = document.createElement("div");
    errEl.className = "field-error-msg";
    input.parentNode.appendChild(errEl);
  }
  errEl.textContent = "⚠️ " + errorText;
}

// Helper: Clear field error
function clearFieldError(fieldId) {
  const input = document.getElementById(fieldId);
  if (!input) return;
  input.classList.remove("invalid");
  const errEl = input.parentNode.querySelector(".field-error-msg");
  if (errEl) errEl.remove();
}

// Real-time input clearing
["fullname", "signup-email", "signup-password", "confirm-password", "terms"].forEach(id => {
  const el = document.getElementById(id);
  if (el) {
    el.addEventListener("input", () => clearFieldError(id));
    el.addEventListener("change", () => clearFieldError(id));
  }
});

document.getElementById("signup-form").addEventListener("submit", function (e) {
  e.preventDefault();

  let isValid = true;
  const nameInput = document.getElementById("fullname");
  const emailInput = document.getElementById("signup-email");
  const passwordInput = document.getElementById("signup-password");
  const confirmInput = document.getElementById("confirm-password");
  const termsInput = document.getElementById("terms");
  const message = document.getElementById("signup-message");

  // Validate Name
  const nameVal = nameInput ? nameInput.value.trim() : "";
  if (!nameVal) {
    setFieldError("fullname", "Full name is required.");
    isValid = false;
  } else if (nameVal.length < 2) {
    setFieldError("fullname", "Full name must be at least 2 characters.");
    isValid = false;
  } else {
    clearFieldError("fullname");
  }

  // Validate Email
  const emailVal = emailInput ? emailInput.value.trim() : "";
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailVal) {
    setFieldError("signup-email", "Email address is required.");
    isValid = false;
  } else if (!emailRegex.test(emailVal)) {
    setFieldError("signup-email", "Please enter a valid email address.");
    isValid = false;
  } else {
    clearFieldError("signup-email");
  }

  // Validate Password
  const passVal = passwordInput ? passwordInput.value : "";
  if (!passVal) {
    setFieldError("signup-password", "Password is required.");
    isValid = false;
  } else if (passVal.length < 8) {
    setFieldError("signup-password", "Password must be at least 8 characters.");
    isValid = false;
  } else {
    clearFieldError("signup-password");
  }

  // Validate Confirm Password
  const confirmVal = confirmInput ? confirmInput.value : "";
  if (!confirmVal) {
    setFieldError("confirm-password", "Please confirm your password.");
    isValid = false;
  } else if (passVal !== confirmVal) {
    setFieldError("confirm-password", "Passwords do not match.");
    isValid = false;
  } else {
    clearFieldError("confirm-password");
  }

  // Validate Terms Checkbox
  if (termsInput && !termsInput.checked) {
    setFieldError("terms", "You must agree to the Terms of Service & Privacy Policy.");
    isValid = false;
  } else {
    clearFieldError("terms");
  }

  if (!isValid) {
    if (message) {
      message.textContent = "Please fill in all required fields highlighted above.";
      message.className = "form-message error";
    }
    return;
  }

  if (message) {
    message.textContent = "✓ Account created successfully! Launching portal...";
    message.className = "form-message success";
  }

  try {
    localStorage.setItem("hb_logged_in", "true");
  } catch (err) {}

  setTimeout(function () {
    window.location.href = "loading.html?type=signup";
  }, 600);
});
