// ============================================================
// Hirebase job board — search, filter, sort, save & applied
// tracking (localStorage), job details drawer, Easy Apply form,
// salary estimator, and toast notifications.
// Runs only on Index.html (guards below no-op elsewhere).
// ============================================================

(function () {
  const grid = document.getElementById("job-grid");
  if (!grid) return; // not on the home page

  // ---------- Mock job dataset ----------
  const JOBS = [
    { id: "j1", title: "Product Designer", company: "Nimbus Labs", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 110, salaryMax: 140, skills: ["Figma", "TypeScript"], category: "Design", postedDaysAgo: 1, match: 96,
      summary: "Own end-to-end product design for our core scheduling app, from research through polished UI.",
      responsibilities: ["Lead design for 2-3 product areas", "Run user research and usability tests", "Partner closely with engineering on implementation"],
      qualifications: ["4+ years product design experience", "Strong portfolio in Figma", "Comfortable working with design systems"] },
    { id: "j2", title: "Backend Engineer", company: "Cursive", location: "Bengaluru, IN", worktype: "On-site", jobtype: "Full-time", salaryMin: 90, salaryMax: 120, skills: ["Node.js", "TypeScript"], category: "Engineering", postedDaysAgo: 2, match: 91,
      summary: "Build and scale the APIs powering our payments infrastructure.",
      responsibilities: ["Design and ship backend services in Node.js", "Own reliability and on-call for core APIs", "Mentor junior engineers"],
      qualifications: ["3+ years backend engineering", "Experience with distributed systems", "SQL and API design fundamentals"] },
    { id: "j3", title: "Marketing Intern", company: "Petal & Co", location: "Pune, IN", worktype: "Hybrid", jobtype: "Internship", salaryMin: 40, salaryMax: 50, skills: [], category: "Marketing", postedDaysAgo: 4, match: 74,
      summary: "Support campaign planning and content creation for a fast-growing consumer brand.",
      responsibilities: ["Assist with social and email campaigns", "Draft copy and creative briefs", "Track campaign performance metrics"],
      qualifications: ["Currently pursuing a marketing or communications degree", "Strong writing skills", "Familiarity with social platforms"] },
    { id: "j4", title: "Frontend Engineer", company: "Cursive", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 100, salaryMax: 135, skills: ["React", "TypeScript"], category: "Engineering", postedDaysAgo: 1, match: 94,
      summary: "Build the customer-facing dashboard used by thousands of merchants daily.",
      responsibilities: ["Develop features in React and TypeScript", "Collaborate with design on UI polish", "Improve performance and accessibility"],
      qualifications: ["3+ years frontend experience", "Strong React fundamentals", "Eye for detail in UI implementation"] },
    { id: "j5", title: "Data Scientist", company: "OpenLoop", location: "Hyderabad, IN", worktype: "Hybrid", jobtype: "Full-time", salaryMin: 130, salaryMax: 170, skills: ["Python"], category: "Engineering", postedDaysAgo: 6, match: 88,
      summary: "Build models that power personalized recommendations for millions of users.",
      responsibilities: ["Develop and evaluate ML models", "Partner with product on experimentation", "Present findings to stakeholders"],
      qualifications: ["Experience with Python and ML frameworks", "Strong statistics fundamentals", "Comfortable with ambiguous problems"] },
    { id: "j6", title: "Customer Support Specialist", company: "Petal & Co", location: "Chennai, IN", worktype: "On-site", jobtype: "Full-time", salaryMin: 48, salaryMax: 60, skills: [], category: "Support", postedDaysAgo: 3, match: 80,
      summary: "Be the first point of contact for customers, resolving issues with empathy and speed.",
      responsibilities: ["Respond to customer inquiries across chat and email", "Track and escalate recurring issues", "Maintain help center content"],
      qualifications: ["1+ years in a customer-facing role", "Clear written communication", "Patient, empathetic approach"] },
    { id: "j7", title: "Senior Product Designer", company: "Nimbus Labs", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 145, salaryMax: 185, skills: ["Figma"], category: "Design", postedDaysAgo: 5, match: 90,
      summary: "Shape design direction across our platform and mentor a growing design team.",
      responsibilities: ["Set design direction for core product surfaces", "Mentor 2 mid-level designers", "Partner with leadership on strategy"],
      qualifications: ["6+ years product design experience", "Track record leading 0-to-1 work", "Experience mentoring other designers"] },
    { id: "j8", title: "DevOps Engineer", company: "OpenLoop", location: "Remote, India", worktype: "Remote", jobtype: "Contract", salaryMin: 95, salaryMax: 130, skills: ["Node.js"], category: "Engineering", postedDaysAgo: 2, match: 85,
      summary: "Harden our deployment pipeline and improve infrastructure reliability.",
      responsibilities: ["Maintain CI/CD pipelines", "Improve monitoring and alerting", "Support incident response"],
      qualifications: ["Experience with cloud infrastructure", "Comfortable with Linux and containers", "Scripting experience"] },
    { id: "j9", title: "Growth Marketing Manager", company: "Petal & Co", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 85, salaryMax: 110, skills: [], category: "Marketing", postedDaysAgo: 7, match: 78,
      summary: "Own paid acquisition strategy and scale our highest-performing channels.",
      responsibilities: ["Manage paid acquisition budget", "Run and analyze experiments", "Report on channel performance"],
      qualifications: ["3+ years growth marketing experience", "Comfortable with analytics tooling", "Strong analytical mindset"] },
    { id: "j10", title: "Full Stack Engineer", company: "Cursive", location: "Gurugram, IN", worktype: "Hybrid", jobtype: "Full-time", salaryMin: 105, salaryMax: 140, skills: ["React", "Node.js"], category: "Engineering", postedDaysAgo: 1, match: 93,
      summary: "Work across the stack to ship features from database to UI.",
      responsibilities: ["Build features across frontend and backend", "Participate in code review", "Help shape technical direction"],
      qualifications: ["3+ years full stack experience", "Comfortable in React and Node.js", "Product-minded engineering approach"] },
    { id: "j11", title: "UX Researcher", company: "OpenLoop", location: "Remote, India", worktype: "Remote", jobtype: "Contract", salaryMin: 90, salaryMax: 115, skills: ["Figma"], category: "Design", postedDaysAgo: 8, match: 82,
      summary: "Run qualitative and quantitative research to guide product decisions.",
      responsibilities: ["Plan and run user interviews", "Synthesize findings into actionable insights", "Partner with designers on research plans"],
      qualifications: ["Experience running mixed-methods research", "Strong synthesis and communication skills", "Comfortable presenting to stakeholders"] },
    { id: "j12", title: "Support Team Lead", company: "Nimbus Labs", location: "Kolkata, IN", worktype: "On-site", jobtype: "Full-time", salaryMin: 65, salaryMax: 85, skills: [], category: "Support", postedDaysAgo: 4, match: 79,
      summary: "Lead a small support team and improve response quality and speed.",
      responsibilities: ["Manage and coach a team of support specialists", "Set quality and response-time standards", "Report on support metrics"],
      qualifications: ["2+ years in a support leadership role", "Experience with support tooling", "Strong coaching skills"] },
    { id: "j13", title: "Cloud Infrastructure Architect", company: "Nexus Systems", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 150, salaryMax: 190, skills: ["Node.js", "Python"], category: "Engineering", postedDaysAgo: 1, match: 97,
      summary: "Architect automated Kubernetes clusters and zero-trust cloud pipelines.",
      responsibilities: ["Lead cloud architecture across AWS & GCP", "Optimize CI/CD build speeds", "Implement zero-trust security"],
      qualifications: ["5+ years cloud architecture experience", "Deep knowledge of Kubernetes & Terraform", "Strong security mindset"] },
    { id: "j14", title: "AI Research Engineer", company: "Quantum Mind Labs", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 160, salaryMax: 200, skills: ["Python"], category: "Engineering", postedDaysAgo: 2, match: 95,
      summary: "Train and fine-tune multimodal generative AI models for enterprise customer operations.",
      responsibilities: ["Fine-tune open-weight LLMs", "Optimize GPU inference latency", "Publish research benchmarks"],
      qualifications: ["Master's or PhD in CS/AI or equivalent", "Experience with PyTorch and CUDA", "Strong math fundamentals"] },
    { id: "j15", title: "Lead Product Designer", company: "Prism Studio", location: "Bengaluru, IN", worktype: "Hybrid", jobtype: "Full-time", salaryMin: 130, salaryMax: 165, skills: ["Figma"], category: "Design", postedDaysAgo: 3, match: 92,
      summary: "Direct design systems and user experience strategy for flagship fintech applications.",
      responsibilities: ["Establish design tokens and component libraries", "Lead usability interviews", "Partner with product managers"],
      qualifications: ["5+ years product design background", "Expertise in Figma design systems", "Strong micro-interaction portfolio"] },
    { id: "j16", title: "Cybersecurity Analyst", company: "Velocity Cyber", location: "Remote, India", worktype: "Remote", jobtype: "Contract", salaryMin: 110, salaryMax: 145, skills: ["Python"], category: "Engineering", postedDaysAgo: 1, match: 89,
      summary: "Monitor API endpoints and defend against automated threat vectors in real time.",
      responsibilities: ["Perform vulnerability assessments", "Automate incident response scripts", "Conduct penetration tests"],
      qualifications: ["3+ years cybersecurity experience", "Relevant certifications (CISSP/CEH)", "Proficiency in Python scripting"] },
    { id: "j17", title: "Fintech Backend Developer", company: "Zenith Pay", location: "Mumbai, IN", worktype: "Hybrid", jobtype: "Full-time", salaryMin: 120, salaryMax: 155, skills: ["Node.js", "TypeScript"], category: "Engineering", postedDaysAgo: 2, match: 93,
      summary: "Develop low-latency payment processing APIs and fraud prevention logic.",
      responsibilities: ["Build fault-tolerant payment gateways", "Implement real-time transaction monitoring", "Partner with compliance teams"],
      qualifications: ["3+ years backend experience in Node.js/Go", "Experience with banking APIs & PCI-DSS", "SQL tuning skills"] },
    { id: "j18", title: "3D Motion Designer", company: "Apex Interactive", location: "Remote, India", worktype: "Remote", jobtype: "Contract", salaryMin: 95, salaryMax: 125, skills: ["Figma"], category: "Design", postedDaysAgo: 4, match: 87,
      summary: "Create immersive 3D graphics and web animations for AAA gaming portals.",
      responsibilities: ["Design 3D interactive assets", "Create smooth WebGL / Three.js animations", "Collaborate with frontend developers"],
      qualifications: ["3+ years motion design experience", "Proficiency in Blender/Cinema4D & WebGL", "Strong visual demo reel"] },
    { id: "j19", title: "CleanTech Data Engineer", company: "Solis Climate Tech", location: "Bengaluru, IN", worktype: "On-site", jobtype: "Full-time", salaryMin: 105, salaryMax: 140, skills: ["Python"], category: "Engineering", postedDaysAgo: 3, match: 88,
      summary: "Process solar smart-grid IoT data streams to optimize renewable power distribution.",
      responsibilities: ["Build ETL data pipelines", "Maintain real-time Kafka streams", "Create data dashboards for energy grid operators"],
      qualifications: ["3+ years data engineering background", "Proficiency in Python, SQL, and Spark", "Interest in renewable energy"] },
    { id: "j20", title: "Content & SEO Specialist", company: "Orbit Media", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 70, salaryMax: 90, skills: [], category: "Marketing", postedDaysAgo: 1, match: 86,
      summary: "Lead organic search strategy, technical SEO audits, and high-converting content creation.",
      responsibilities: ["Execute keyword research and content strategy", "Run technical SEO audits", "Track domain authority metrics"],
      qualifications: ["3+ years in B2B SaaS content marketing", "Proven track record ranking organic search terms", "SEO tool mastery"] },
    { id: "j21", title: "Product Marketing Lead", company: "Cursive", location: "Bengaluru, IN", worktype: "Hybrid", jobtype: "Full-time", salaryMin: 115, salaryMax: 145, skills: [], category: "Marketing", postedDaysAgo: 2, match: 91,
      summary: "Own product positioning, launch strategy, and sales enablement collateral for enterprise APIs.",
      responsibilities: ["Lead GTM launch campaigns for 3 core APIs", "Create product messaging frameworks", "Partner with sales on enablement"],
      qualifications: ["4+ years product marketing experience", "Experience in developer-focused fintech SaaS", "Strong storytelling skills"] },
    { id: "j22", title: "Social Media Strategy Manager", company: "Petal & Co", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 80, salaryMax: 105, skills: [], category: "Marketing", postedDaysAgo: 3, match: 84,
      summary: "Build brand awareness and community engagement across Instagram, LinkedIn, and YouTube.",
      responsibilities: ["Develop video and editorial content calendar", "Manage influencer partnerships", "Analyze channel ROI"],
      qualifications: ["3+ years social strategy background", "Strong video editing & copywriting skills", "Data-driven approach"] },
    { id: "j23", title: "Brand Strategist", company: "Prism Studio", location: "Mumbai, IN", worktype: "Hybrid", jobtype: "Contract", salaryMin: 90, salaryMax: 120, skills: [], category: "Marketing", postedDaysAgo: 4, match: 82,
      summary: "Develop brand identity frameworks and campaign messaging for hyper-growth tech startups.",
      responsibilities: ["Conduct brand discovery workshops", "Draft brand voice guidelines", "Coordinate launch campaigns"],
      qualifications: ["4+ years agency or in-house brand experience", "Strong portfolio of brand transformations", "Excellent presentation skills"] },
    { id: "j24", title: "Customer Success Manager", company: "Strata SaaS", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 75, salaryMax: 95, skills: [], category: "Support", postedDaysAgo: 1, match: 89,
      summary: "Manage enterprise customer relationships, onboard new accounts, and drive retention.",
      responsibilities: ["Lead customer onboarding sessions", "Monitor account health scores", "Drive renewal and expansion revenue"],
      qualifications: ["2+ years B2B SaaS Customer Success experience", "Strong communication & problem solving", "Familiarity with CRM tools"] },
    { id: "j25", title: "Technical Support Engineer", company: "Nexus Systems", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 85, salaryMax: 110, skills: ["Node.js"], category: "Support", postedDaysAgo: 2, match: 92,
      summary: "Troubleshoot complex cloud API integrations and assist enterprise developer clients.",
      responsibilities: ["Investigate developer API tickets", "Write reproducible code samples", "File bug reports for core engineering"],
      qualifications: ["2+ years technical support or developer advocate experience", "Working knowledge of REST APIs & SQL", "Empathy & clear communication"] },
    { id: "j26", title: "Tier 2 Support Lead", company: "OpenLoop", location: "Hyderabad, IN", worktype: "On-site", jobtype: "Full-time", salaryMin: 70, salaryMax: 90, skills: [], category: "Support", postedDaysAgo: 3, match: 81,
      summary: "Escalate complex technical queries and train Tier 1 support representatives.",
      responsibilities: ["Handle escalated technical tickets", "Maintain internal knowledge base", "Conduct support quality audits"],
      qualifications: ["3+ years technical support experience", "Leadership or mentoring experience", "SLA management background"] },
    { id: "j27", title: "Customer Operations Director", company: "Zenith Pay", location: "Mumbai, IN", worktype: "Hybrid", jobtype: "Full-time", salaryMin: 130, salaryMax: 165, skills: [], category: "Support", postedDaysAgo: 5, match: 87,
      summary: "Scale 24/7 global customer operations and optimize support automation workflows.",
      responsibilities: ["Oversee 30+ person global support organization", "Implement AI resolution chatbots", "Manage support budget & SLAs"],
      qualifications: ["6+ years customer ops leadership", "Proven track record scaling global support teams", "Data-driven operational mindset"] },
    { id: "j28", title: "UI & Interaction Designer", company: "Glow Interactive", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 105, salaryMax: 135, skills: ["Figma"], category: "Design", postedDaysAgo: 1, match: 94,
      summary: "Craft fluid micro-interactions and visual component libraries for web applications.",
      responsibilities: ["Design high-fidelity UI wireframes and interactive prototypes", "Create micro-animation specs", "Conduct visual QA"],
      qualifications: ["3+ years UI design experience", "Expertise in Figma and Principle/Framer", "Strong eye for typography & spacing"] },
    { id: "j29", title: "Lead Brand Designer", company: "Ink & Pixel", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 125, salaryMax: 155, skills: ["Figma"], category: "Design", postedDaysAgo: 2, match: 91,
      summary: "Shape visual brand identity, marketing assets, and web design for tech unicorns.",
      responsibilities: ["Set brand design direction", "Create visual guidelines and marketing systems", "Direct junior visual designers"],
      qualifications: ["5+ years brand design background", "Stunning portfolio in web and brand design", "Leadership skills"] },
    { id: "j30", title: "Design Systems Engineer", company: "Nimbus Labs", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 135, salaryMax: 170, skills: ["React", "Figma", "TypeScript"], category: "Design", postedDaysAgo: 1, match: 96,
      summary: "Bridge the gap between design and code by building reusable React UI component libraries.",
      responsibilities: ["Build accessible React/TypeScript design token libraries", "Maintain Storybook documentation", "Partner with design team"],
      qualifications: ["4+ years design engineering experience", "Proficiency in React, TypeScript, and Storybook", "Strong accessibility knowledge"] },
    { id: "j31", title: "React Native Mobile Developer", company: "Mobile Flow", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 110, salaryMax: 145, skills: ["React", "TypeScript"], category: "Engineering", postedDaysAgo: 2, match: 93,
      summary: "Build high-performance iOS and Android mobile apps in React Native.",
      responsibilities: ["Develop consumer mobile features in React Native", "Optimize app startup performance", "Maintain Native modules"],
      qualifications: ["3+ years React Native experience", "Experience publishing to App Store & Google Play", "TypeScript proficiency"] },
    { id: "j32", title: "Senior Python & AI Engineer", company: "Cognitive AI", location: "Bengaluru, IN", worktype: "Hybrid", jobtype: "Full-time", salaryMin: 130, salaryMax: 170, skills: ["Python"], category: "Engineering", postedDaysAgo: 1, match: 95,
      summary: "Develop enterprise NLP pipelines and conversational AI frameworks.",
      responsibilities: ["Ship production Python microservices for LLM orchestration", "Optimize model latency", "Maintain vector database pipelines"],
      qualifications: ["4+ years Python engineering background", "Experience with FastAPI, PyTorch, and LangChain", "Strong API design"] },
    { id: "j33", title: "Principal Fullstack Architect", company: "Core Stack Inc", location: "Remote, India", worktype: "Remote", jobtype: "Full-time", salaryMin: 165, salaryMax: 210, skills: ["React", "Node.js", "TypeScript"], category: "Engineering", postedDaysAgo: 1, match: 98,
      summary: "Lead technical architecture for our next-generation developer tooling ecosystem.",
      responsibilities: ["Architect scalable frontend and backend systems", "Establish code quality standards", "Mentor staff engineers"],
      qualifications: ["7+ years fullstack architecture experience", "Mastery of React, Node.js, and TypeScript", "Track record shipping large-scale SaaS"] }
  ];

  // ---------- Persisted state ----------
  function loadIdSet(key) {
    try {
      return new Set(JSON.parse(localStorage.getItem(key) || "[]"));
    } catch (e) {
      return new Set();
    }
  }
  function saveIdSet(key, set) {
    try {
      localStorage.setItem(key, JSON.stringify([...set]));
    } catch (e) {
      /* ignore */
    }
  }

  const state = {
    savedIds: loadIdSet("hb_saved_jobs"),
    appliedIds: loadIdSet("hb_applied_jobs"),
    tab: "all",
    search: "",
    category: null, // set via category card click
    worktypes: new Set(["Remote", "Hybrid", "On-site"]),
    jobtypes: new Set(["Full-time", "Contract", "Internship"]),
    minSalary: 40,
    skill: "All",
    sort: "match",
    activeJobId: null // for the apply modal
  };

  // ---------- DOM refs ----------
  const DOM = {
    grid,
    emptyState: document.getElementById("empty-state"),
    resultCount: document.getElementById("jobs-result-count"),
    tabsWrap: document.querySelector(".jobs-tabs"),
    countAll: document.getElementById("count-all"),
    countSaved: document.getElementById("count-saved"),
    countApplied: document.getElementById("count-applied"),
    heroForm: document.getElementById("hero-search-form"),
    heroInput: document.getElementById("job-search"),
    categoryCards: document.querySelectorAll(".category-card"),
    worktypeChecks: document.querySelectorAll(".f-worktype"),
    jobtypeChecks: document.querySelectorAll(".f-jobtype"),
    cntRemote: document.getElementById("cnt-remote"),
    cntHybrid: document.getElementById("cnt-hybrid"),
    cntOnsite: document.getElementById("cnt-onsite"),
    salaryRange: document.getElementById("salary-range"),
    salaryRangeVal: document.getElementById("salary-range-val"),
    skillPills: document.getElementById("skill-pills"),
    sortSelect: document.getElementById("sort-select"),
    resetFilters: document.getElementById("reset-filters"),
    detailsModal: document.getElementById("details-modal"),
    detailsContent: document.getElementById("details-content"),
    detailsClose: document.getElementById("details-close"),
    applyModal: document.getElementById("apply-modal"),
    applyForm: document.getElementById("apply-form"),
    applyClose: document.getElementById("apply-close"),
    applyRole: document.getElementById("apply-role"),
    applyCompany: document.getElementById("apply-company"),
    applyMessage: document.getElementById("apply-message"),
    calcRole: document.getElementById("calc-role"),
    calcExp: document.getElementById("calc-exp"),
    estimateAmount: document.getElementById("estimate-amount"),
    toastContainer: document.getElementById("toast-container")
  };

  // ---------- Filtering & sorting ----------
  function getFilteredJobs() {
    return JOBS.filter((job) => {
      if (state.tab === "saved" && !state.savedIds.has(job.id)) return false;
      if (state.tab === "applied" && !state.appliedIds.has(job.id)) return false;

      if (!state.worktypes.has(job.worktype)) return false;
      if (!state.jobtypes.has(job.jobtype)) return false;
      if (job.salaryMax < state.minSalary) return false;
      if (state.skill !== "All" && !job.skills.includes(state.skill)) return false;
      if (state.category && job.category !== state.category) return false;

      if (state.search) {
        const haystack = (job.title + " " + job.company + " " + job.skills.join(" ")).toLowerCase();
        if (!haystack.includes(state.search.toLowerCase())) return false;
      }
      return true;
    });
  }

  function getSortedJobs(jobs) {
    const copy = [...jobs];
    if (state.sort === "newest") copy.sort((a, b) => a.postedDaysAgo - b.postedDaysAgo);
    else if (state.sort === "salary") copy.sort((a, b) => b.salaryMax - a.salaryMax);
    else copy.sort((a, b) => b.match - a.match);
    return copy;
  }

  function updateWorktypeCounts() {
    const base = JOBS.filter((job) => {
      if (state.tab === "saved" && !state.savedIds.has(job.id)) return false;
      if (state.tab === "applied" && !state.appliedIds.has(job.id)) return false;
      if (state.category && job.category !== state.category) return false;
      return true;
    });
    DOM.cntRemote.textContent = base.filter((j) => j.worktype === "Remote").length;
    DOM.cntHybrid.textContent = base.filter((j) => j.worktype === "Hybrid").length;
    DOM.cntOnsite.textContent = base.filter((j) => j.worktype === "On-site").length;
  }

  function updateTabCounts() {
    DOM.countAll.textContent = JOBS.length;
    DOM.countSaved.textContent = state.savedIds.size;
    DOM.countApplied.textContent = state.appliedIds.size;
  }

  // ---------- Rendering ----------
  function tagClass(jobtype) {
    if (jobtype === "Full-time") return "tag-fulltime";
    if (jobtype === "Internship") return "tag-internship";
    return "tag-contract";
  }

  function createJobCardHTML(job) {
    const saved = state.savedIds.has(job.id);
    const applied = state.appliedIds.has(job.id);
    const skillsText = job.skills.length ? job.skills.join(" · ") : "No specific skill requirement";

    return `
      <article class="job-card" data-id="${job.id}">
        <div class="job-card-top">
          <div>
            <h3>${job.title}</h3>
            <p class="job-meta">${job.company} &middot; ${job.location}</p>
          </div>
          <button class="save-btn ${saved ? "saved" : ""}" data-action="save" data-id="${job.id}" aria-label="${saved ? "Unsave job" : "Save job"}">${saved ? "★" : "☆"}</button>
        </div>
        <div class="job-tags">
          <span class="tag ${tagClass(job.jobtype)}">${job.jobtype}</span>
          <span class="tag tag-salary">$${job.salaryMin}k&ndash;$${job.salaryMax}k</span>
        </div>
        <p class="job-skills">${skillsText}</p>
        <div class="job-card-actions">
          <button class="btn-details" data-action="details" data-id="${job.id}">View details</button>
          <button class="btn-apply ${applied ? "applied" : ""}" data-action="apply" data-id="${job.id}">${applied ? "Applied" : "Easy Apply"}</button>
        </div>
      </article>
    `;
  }

  function renderFeed() {
    const filtered = getFilteredJobs();
    const sorted = getSortedJobs(filtered);

    DOM.resultCount.textContent = `${sorted.length} role${sorted.length === 1 ? "" : "s"}`;

    if (sorted.length === 0) {
      DOM.grid.innerHTML = "";
      DOM.emptyState.hidden = false;
    } else {
      DOM.emptyState.hidden = true;
      DOM.grid.innerHTML = sorted.map(createJobCardHTML).join("");
    }

    updateWorktypeCounts();
    updateTabCounts();
  }

  // ---------- Save / bookmark ----------
  function toggleSave(id) {
    if (state.savedIds.has(id)) {
      state.savedIds.delete(id);
      showToast("Removed from saved jobs");
    } else {
      state.savedIds.add(id);
      showToast("Job saved");
    }
    saveIdSet("hb_saved_jobs", state.savedIds);
    renderFeed();
  }

  // ---------- Job details modal ----------
  function openDetailsModal(id) {
    const job = JOBS.find((j) => j.id === id);
    if (!job) return;

    const saved = state.savedIds.has(job.id);
    const applied = state.appliedIds.has(job.id);

    DOM.detailsContent.innerHTML = `
      <h3 class="details-title">${job.title}</h3>
      <p class="details-company">${job.company} &middot; ${job.location} &middot; ${job.worktype}</p>
      <div class="details-tags">
        <span class="tag ${tagClass(job.jobtype)}">${job.jobtype}</span>
        <span class="tag tag-salary">$${job.salaryMin}k&ndash;$${job.salaryMax}k / yr</span>
      </div>
      <div class="details-section">
        <h4>About the role</h4>
        <p>${job.summary}</p>
      </div>
      <div class="details-section">
        <h4>Responsibilities</h4>
        <ul>${job.responsibilities.map((r) => `<li>${r}</li>`).join("")}</ul>
      </div>
      <div class="details-section">
        <h4>Qualifications</h4>
        <ul>${job.qualifications.map((q) => `<li>${q}</li>`).join("")}</ul>
      </div>
      <div class="details-actions">
        <button class="btn-apply ${applied ? "applied" : ""}" data-action="apply" data-id="${job.id}" style="flex:1;">${applied ? "Applied" : "Easy Apply"}</button>
        <button class="save-btn ${saved ? "saved" : ""}" data-action="save" data-id="${job.id}" aria-label="${saved ? "Unsave job" : "Save job"}">${saved ? "★" : "☆"}</button>
      </div>
    `;
    DOM.detailsModal.hidden = false;
  }

  function closeDetailsModal() {
    DOM.detailsModal.hidden = true;
  }

  // ---------- Easy Apply modal ----------
  function openApplyModal(id) {
    const job = JOBS.find((j) => j.id === id);
    if (!job) return;
    if (state.appliedIds.has(id)) {
      showToast("You've already applied to this role");
      return;
    }

    state.activeJobId = id;
    DOM.applyRole.textContent = job.title;
    DOM.applyCompany.textContent = job.company;
    DOM.applyMessage.textContent = "";
    DOM.applyMessage.classList.remove("success");
    DOM.applyForm.reset();
    DOM.applyModal.hidden = false;
  }

  function closeApplyModal() {
    DOM.applyModal.hidden = true;
    state.activeJobId = null;
  }

  function handleApplySubmit(e) {
    e.preventDefault();
    const nameEl = document.getElementById("apply-name");
    const emailEl = document.getElementById("apply-email");
    const phoneEl = document.getElementById("apply-phone");
    const resumeEl = document.getElementById("apply-resume");
    const pitchEl = document.getElementById("apply-pitch");

    const name = nameEl ? nameEl.value.trim() : "";
    const email = emailEl ? emailEl.value.trim() : "";
    const phone = phoneEl ? phoneEl.value.trim() : "";
    const resume = resumeEl ? resumeEl.value.trim() : "";
    const pitch = pitchEl ? pitchEl.value.trim() : "";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    let isValid = true;
    if (!name) { if (nameEl) nameEl.classList.add("invalid"); isValid = false; } else { if (nameEl) nameEl.classList.remove("invalid"); }
    if (!email || !emailRegex.test(email)) { if (emailEl) emailEl.classList.add("invalid"); isValid = false; } else { if (emailEl) emailEl.classList.remove("invalid"); }
    if (!phone) { if (phoneEl) phoneEl.classList.add("invalid"); isValid = false; } else { if (phoneEl) phoneEl.classList.remove("invalid"); }
    if (!resume) { if (resumeEl) resumeEl.classList.add("invalid"); isValid = false; } else { if (resumeEl) resumeEl.classList.remove("invalid"); }
    if (!pitch) { if (pitchEl) pitchEl.classList.add("invalid"); isValid = false; } else { if (pitchEl) pitchEl.classList.remove("invalid"); }

    if (!isValid) {
      DOM.applyMessage.textContent = "Please fill in all required fields highlighted in red.";
      DOM.applyMessage.className = "form-message error";
      return;
    }

    const id = state.activeJobId;
    if (!id) return;

    state.appliedIds.add(id);
    saveIdSet("hb_applied_jobs", state.appliedIds);

    DOM.applyMessage.textContent = "✓ Application submitted successfully!";
    DOM.applyMessage.className = "form-message success";
    DOM.applyMessage.classList.add("success");

    setTimeout(() => {
      closeApplyModal();
      closeDetailsModal();
      renderFeed();
      showToast("Application sent successfully");
    }, 700);
  }

  // ---------- Salary estimator ----------
  const SALARY_RANGES = {
    software: { junior: [80, 105], mid: [105, 140], senior: [140, 180], lead: [175, 230] },
    design: { junior: [70, 95], mid: [95, 130], senior: [130, 165], lead: [160, 200] },
    product: { junior: [85, 110], mid: [115, 150], senior: [150, 190], lead: [185, 240] },
    data: { junior: [90, 115], mid: [120, 155], senior: [155, 195], lead: [190, 245] }
  };

  function updateSalaryEstimator() {
    const role = DOM.calcRole.value;
    const exp = DOM.calcExp.value;
    const range = (SALARY_RANGES[role] && SALARY_RANGES[role][exp]) || [80, 120];
    DOM.estimateAmount.textContent = `$${range[0]},000 - $${range[1]},000`;
  }

  // ---------- Toast ----------
  function showToast(message, type = "info") {
    const toast = document.createElement("div");
    toast.className = `toast ${type === "error" ? "toast-error" : ""}`;
    toast.textContent = message;
    DOM.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("toast-out");
      setTimeout(() => toast.remove(), 200);
    }, 2400);
  }

  // ---------- Event delegation for job card / details actions ----------
  function handleActionClick(e) {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const { action, id } = btn.dataset;
    if (action === "save") toggleSave(id);
    else if (action === "details") openDetailsModal(id);
    else if (action === "apply") openApplyModal(id);
  }

  // ---------- Event listeners ----------
  function setupEventListeners() {
    DOM.grid.addEventListener("click", handleActionClick);
    DOM.detailsContent.addEventListener("click", handleActionClick);

    DOM.tabsWrap.addEventListener("click", (e) => {
      const btn = e.target.closest(".tab-btn");
      if (!btn) return;
      DOM.tabsWrap.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.tab = btn.dataset.tab;
      renderFeed();
    });

    if (DOM.heroForm) {
      DOM.heroForm.addEventListener("submit", (e) => {
        e.preventDefault();
        state.search = DOM.heroInput.value.trim();
        renderFeed();
        document.getElementById("jobs-board").scrollIntoView({ behavior: "smooth", block: "start" });
      });
      DOM.heroInput.addEventListener("input", (e) => {
        state.search = e.target.value.trim();
        renderFeed();
      });
    }

    DOM.categoryCards.forEach((card) => {
      card.addEventListener("click", () => {
        const cat = card.dataset.category;
        const alreadyActive = card.classList.contains("active");
        DOM.categoryCards.forEach((c) => c.classList.remove("active"));
        if (alreadyActive) {
          state.category = null;
        } else {
          card.classList.add("active");
          state.category = cat;
        }
        renderFeed();
        document.getElementById("jobs-board").scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });

    DOM.worktypeChecks.forEach((cb) => {
      cb.addEventListener("change", () => {
        state.worktypes = new Set([...DOM.worktypeChecks].filter((c) => c.checked).map((c) => c.value));
        renderFeed();
      });
    });

    DOM.jobtypeChecks.forEach((cb) => {
      cb.addEventListener("change", () => {
        state.jobtypes = new Set([...DOM.jobtypeChecks].filter((c) => c.checked).map((c) => c.value));
        renderFeed();
      });
    });

    DOM.salaryRange.addEventListener("input", (e) => {
      state.minSalary = Number(e.target.value);
      DOM.salaryRangeVal.textContent = `$${state.minSalary}k+ / yr`;
      renderFeed();
    });

    DOM.skillPills.addEventListener("click", (e) => {
      const pill = e.target.closest(".skill-pill");
      if (!pill) return;
      DOM.skillPills.querySelectorAll(".skill-pill").forEach((p) => p.classList.remove("active"));
      pill.classList.add("active");
      state.skill = pill.dataset.skill;
      renderFeed();
    });

    DOM.sortSelect.addEventListener("change", (e) => {
      state.sort = e.target.value;
      renderFeed();
    });

    DOM.resetFilters.addEventListener("click", () => {
      state.worktypes = new Set(["Remote", "Hybrid", "On-site"]);
      state.jobtypes = new Set(["Full-time", "Contract", "Internship"]);
      state.minSalary = 40;
      state.skill = "All";
      state.category = null;
      DOM.worktypeChecks.forEach((c) => (c.checked = true));
      DOM.jobtypeChecks.forEach((c) => (c.checked = true));
      DOM.salaryRange.value = 40;
      DOM.salaryRangeVal.textContent = "$40k+ / yr";
      DOM.skillPills.querySelectorAll(".skill-pill").forEach((p) => p.classList.toggle("active", p.dataset.skill === "All"));
      DOM.categoryCards.forEach((c) => c.classList.remove("active"));
      renderFeed();
    });

    DOM.detailsClose.addEventListener("click", closeDetailsModal);
    DOM.detailsModal.addEventListener("click", (e) => {
      if (e.target === DOM.detailsModal) closeDetailsModal();
    });

    DOM.applyClose.addEventListener("click", closeApplyModal);
    DOM.applyModal.addEventListener("click", (e) => {
      if (e.target === DOM.applyModal) closeApplyModal();
    });
    DOM.applyForm.addEventListener("submit", handleApplySubmit);

    DOM.calcRole.addEventListener("change", updateSalaryEstimator);
    DOM.calcExp.addEventListener("change", updateSalaryEstimator);

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        closeDetailsModal();
        closeApplyModal();
      }
    });
  }

  // ---------- Init ----------
  setupEventListeners();
  updateSalaryEstimator();
  renderFeed();
})();
